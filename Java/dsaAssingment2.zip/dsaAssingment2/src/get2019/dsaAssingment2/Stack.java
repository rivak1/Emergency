package get2019.dsaAssingment2;

public interface Stack {

	void push(String data);
	void pop ();
	String peak();
	boolean isEmpty();
	void display();
}
